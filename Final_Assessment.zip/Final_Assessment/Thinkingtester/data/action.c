Action()
{

	/* Add a New Contact */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.5");

	lr_think_time(23);

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(51);

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Gokul\",\"lastName\":\"R\",\"birthdate\":\"1999-10-10\",\"email\":\"test@gmail.com\",\"phone\":\"7989675645\",\"street1\":\"test\",\"street2\":\"test\",\"city\":\"test\",\"stateProvince\":\"test\",\"postalCode\":\"12345\",\"country\":\"india\"}", 
		LAST);

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	/* Clicking on contact */

	lr_think_time(13);

	web_url("contactDetails", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactDetails", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("65d98f4bc0d7050013a34356", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts/65d98f4bc0d7050013a34356", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactDetails", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	/* Delete Contact */

	lr_think_time(12);

	web_custom_request("65d98f4bc0d7050013a34356_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts/65d98f4bc0d7050013a34356", 
		"Method=DELETE", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactDetails", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("contactList_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactDetails", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/contactList.js", ENDITEM, 
		LAST);

	web_custom_request("contacts_4", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
